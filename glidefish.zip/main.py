import pygame
import random


# death, menu screen, score counter, moving screen , sounds

# person goes faster and faster  and the screen ges faster as wel and increases counter based on moveentn
3

pygame.init()

# Define some colors
BLACK = (0, 0, 0)
white = (255, 255, 255)
seaweed_white = (246, 246, 246, 255)
seaweed_white2 = (242, 243, 242)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
sand_blue = (115, 132, 172)

# Set the width and height of the screen [width, height]
width = 450
height = 650
size = (450, 650)
screen = pygame.display.set_mode(size)

# --- Backgroud and text---
underwater_background = pygame.image.load("background (1).jpeg")
font = pygame.font.Font("orange juice 2.0.ttf", 100)
text = font.render("GLIDE FISH ", True, white)
textposition = ((10, 20))

# --- sound ---


# --- scores ---
font2 = pygame.font.SysFont('Verdena', 50)
text2 = font2.render("Score: ", True, white)
textposition2 = (0, 580)

# --- Sand ---
x3 = -20
y3 = 540
sand = pygame.image.load('sand(1).png')
sand.set_colorkey(sand_blue)


def sandtexture(x3, y3):
    screen.blit(sand, (x3, y3))


# ---- seaweed image and position ----
x = 427.5
y = 325
seaweed = pygame.image.load('seaweed.png')
seaweed_x = 450
seaweed_y = random.randrange(height)
seaweed_speed = -0.5
seaweed.set_colorkey(seaweed_white)


def seaweedmoving(x, y):
    screen.blit(seaweed, (x, y))


# ---- crab image and position ----
x4 = 427.5
y4 = 325
crab_x = 450
crab_y = random.randrange(height)
crab_speed = -3
crab = pygame.image.load('crab.png')
crab.set_colorkey(white)


def movingcrab(x4, y4):
    screen.blit(crab, (x4, y4))

# ---- Shark image and position ----
x1 = 427.5
y1 = 325
shark_x = 100
shark_y = random.randrange(height)
shark_speed = -0.5
shark = pygame.image.load('shark.png')
shark.set_colorkey(white)


def movingshark(x1, y1):
    screen.blit(shark, (x1, y1))


# ---- AnglerFish image and position ---
anglerfish = pygame.image.load('glidefish.png')
x_coord = 50
x_speed = 0
y_coord = 300
y_speed = 0
x6 = 0
y6 = 0
rect = anglerfish.get_rect()

def anglerfish_movement(x6, y6):
    screen.blit(anglerfish, (x6, y6))



# --- menu button ---
# START SCREEN
x7 = 0
y7 = 0
# ---Menu---
  #Title for menu 
startscreen_title_font  = pygame.font.Font('startscreenfont3.ttf',100)
startscreen_title = startscreen_title_font.render('GLIDE', True, white)
startscreen_title2 = startscreen_title_font.render('FISH', True, white)
start_title_position = (85,100)
start_title_position2 = (110,200)

  #Subtitle for menu
startscreen_font = pygame.font.Font("startscreenfont2.TTF", 20)
startscreen_subtitle = startscreen_font.render("Press Space to Start", True ,white )
start_position = (55,550)
  #Background Image for start screen
startscreen = pygame.image.load('startscreen.png')
def startscreening (x7,y7):
  screen.blit(startscreen, (x7,y7))
  
menu = True
startgame = False
menuclick = False 

done = False

# have the screen enter only start one time when you click space. make a variable called introduction = true. make a def outside the function called startgame
while not done:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_d:
                x_speed = 0.2


        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                x_speed = -0

        # Holding space Bar makes it go up
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                y_speed = - 1
                menuclick = True

        # Releasing space bar makes it go down
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                y_speed = 1
                menuclick = False 

    # --- Game logic should go here
    # i.e calculations for positions, variable updates
              
    # ---- movement of shark ----
    shark_x += shark_speed
    # Shark border x axis
    if shark_x <= 0:
        shark_x = 450
        shark_y = random.randrange(height)
    # Shark border y axis
    if shark_y <= 85:
        shark_y = 85
    if shark_y >= 495:
        shark_y = 495

    # ---- movement of seaweed ----
    seaweed_x += seaweed_speed
    # Seaweed border x axis
    if seaweed_x <= 0:
        seaweed_x = 450
        seaweed_y = random.randrange(height)
        # Seaweed border for y axis
    if seaweed_y <= 85:
        seaweed_y = 85
    if seaweed_y >= 495:
        seaweed_y = 495

    # ---- movement of angler fish ----
    # movement of anglerfish
    y_coord += y_speed
    x_coord += x_speed
    if y_coord <= 85:
        y_coord = 85
    if y_coord >= 490:
        y_coord = 490
    if x_coord >= 450:
        x_coord = 450
    # --- movement of crab ---
    if crab_x <=0:
        crab_x = 450
        crab_y = random.randrange(height)
    if crab_y <=95:
        crab_y = 95
    if crab_y >= 495:
        crab_y = 495
    crab_x += crab_speed

    # If two objects touch, reset angler fish to x coordinate 0

    # --- Drawing code should go here ----
    # Text

    # Background
    screen.blit(underwater_background, (0, 0))



    # Seaweed
    seaweedmoving(seaweed_x, seaweed_y)
    movingcrab(crab_x, crab_y )
    # Shark
    movingshark(shark_x, shark_y)
    # anglerfish
    anglerfish_movement(x_coord, y_coord)

    # Sand
    sandtexture(x3, y3)
    # Text title
    screen.blit(text, textposition)
    screen.blit(text2, textposition2)
  
    if menu:
      startscreening(x7,y7)
      screen.blit(startscreen_subtitle,start_position)
      screen.blit(startscreen_title, start_title_position)
      screen.blit(startscreen_title2,start_title_position2)
      if menuclick:
        menu = False

    pygame.display.flip()

#flip and clock

# Quit the program
pygame.quit()